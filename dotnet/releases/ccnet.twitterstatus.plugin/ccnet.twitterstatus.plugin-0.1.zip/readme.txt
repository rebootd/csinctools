Purpose:
	publish cruisecontrol.net status messages on twitter
	
Install:
	1) copy folowing files to cruisecontrol.net directory (default location is c:\program files\cruisecontrol.net\server)
		- ccnet.twitterstatus.plugin.dll
		- ccnet.twitterstatus.plugin.pdb
		- Yedda.Twitter.dll
		- Yedda.Twitter.pdb
	2) edit your ccnet.config and add <TwitterStatus/> task to whatever projects you wish to tweet status
	3) edit the xml block for TwitterStatus to use the correct user, password, and desired values for includemachinename and message

Example
	A sample ccnet config file is included.
